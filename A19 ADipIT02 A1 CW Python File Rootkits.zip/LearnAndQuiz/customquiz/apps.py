from django.apps import AppConfig


class CustomquizConfig(AppConfig):
    name = 'customquiz'
